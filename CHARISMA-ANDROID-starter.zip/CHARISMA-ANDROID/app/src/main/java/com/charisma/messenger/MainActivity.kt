package com.charisma.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10131B)
private val Panel = Color(0xFF191E29)
private val Violet = Color(0xFF8B7CFF)
private val Mint = Color(0xFF56D6B0)
private val Muted = Color(0xFF9BA4B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CharismaApp() }
    }
}

private enum class Tab { Chats, Updates, Communities, Calls, Settings }

@Composable
private fun CharismaApp() {
    var tab by remember { mutableStateOf(Tab.Chats) }
    var english by remember { mutableStateOf(false) }
    val title = when (tab) {
        Tab.Chats -> if (english) "Chats" else "المحادثات"
        Tab.Updates -> if (english) "Updates" else "الحالات"
        Tab.Communities -> if (english) "Communities" else "المجتمعات"
        Tab.Calls -> if (english) "Calls" else "المكالمات"
        Tab.Settings -> if (english) "Settings" else "الإعدادات"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Violet,
            secondary = Mint, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("CHARISMA", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("ULTIMATE MESSENGER", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                        }
                        IconButton(onClick = { english = !english }) {
                            Icon(Icons.Default.Translate, contentDescription = "Language", tint = Mint)
                        }
                        IconButton(onClick = { tab = Tab.Settings }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (english) "Your conversations, your control." else "محادثاتك، وخصوصيتك، وتحكمك.",
                        color = Muted, fontSize = 13.sp
                    )
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val entries = listOf(
                        Triple(Tab.Chats, Icons.Default.Chat, if (english) "Chats" else "الدردشات"),
                        Triple(Tab.Updates, Icons.Default.Circle, if (english) "Updates" else "الحالات"),
                        Triple(Tab.Communities, Icons.Default.Groups, if (english) "Groups" else "المجموعات"),
                        Triple(Tab.Calls, Icons.Default.Call, if (english) "Calls" else "المكالمات"),
                        Triple(Tab.Settings, Icons.Default.Settings, if (english) "Settings" else "الإعدادات")
                    )
                    entries.forEach { (destination, icon, label) ->
                        NavigationBarItem(
                            selected = tab == destination,
                            onClick = { tab = destination },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Violet,
                                selectedTextColor = Violet,
                                indicatorColor = Violet.copy(alpha = .15f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab == Tab.Chats) {
                    FloatingActionButton(onClick = { }, containerColor = Violet, contentColor = Color.White) {
                        Icon(Icons.Default.Edit, contentDescription = if (english) "New chat" else "محادثة جديدة")
                    }
                }
            }
        ) { padding ->
            when (tab) {
                Tab.Chats -> ChatsScreen(english, Modifier.padding(padding))
                Tab.Updates -> SimpleScreen(if (english) "Your updates" else "حالاتك", if (english) "Share a photo, video or text update." else "شارك صورة أو فيديو أو حالة نصية.", Modifier.padding(padding))
                Tab.Communities -> SimpleScreen(if (english) "Communities" else "المجتمعات", if (english) "Bring groups together in one place." else "اجمع مجموعاتك ومجتمعاتك في مكان واحد.", Modifier.padding(padding))
                Tab.Calls -> SimpleScreen(if (english) "Calls" else "المكالمات", if (english) "Your voice and video call history will appear here." else "سيظهر سجل مكالماتك الصوتية والمرئية هنا.", Modifier.padding(padding))
                Tab.Settings -> SettingsScreen(english, { english = it }, Modifier.padding(padding))
            }
        }
    }
}

private data class ChatPreview(val name: String, val message: String, val time: String, val initials: String)

@Composable
private fun ChatsScreen(english: Boolean, modifier: Modifier = Modifier) {
    val samples = listOf(
        ChatPreview(if (english) "CHARISMA Team" else "فريق CHARISMA", if (english) "Welcome to your new messenger" else "مرحباً بك في CHARISMA", "10:42", "C"),
        ChatPreview(if (english) "Alex Morgan" else "أحمد", if (english) "Voice message" else "رسالة صوتية", "09:18", "A"),
        ChatPreview(if (english) "Design Group" else "مجموعة التصميم", if (english) "The new theme looks great" else "التصميم الجديد رائع", "أمس", "D"),
        ChatPreview(if (english) "Maya" else "ليلى", if (english) "Photo" else "صورة", "أمس", "M")
    )
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(
            value = "",
            onValueChange = {},
            readOnly = true,
            placeholder = { Text(if (english) "Search chats" else "ابحث في المحادثات", color = Muted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Panel,
                focusedContainerColor = Panel,
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Violet
            )
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(samples) { chat ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .clickable { }.padding(vertical = 12.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(50.dp).clip(CircleShape).background(Violet.copy(alpha = .22f)),
                        contentAlignment = Alignment.Center
                    ) { Text(chat.initials, color = Violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(chat.message, color = Muted, fontSize = 13.sp)
                    }
                    Text(chat.time, color = Muted, fontSize = 11.sp)
                }
                HorizontalDivider(color = Color.White.copy(alpha = .06f))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            if (english) "Preview build — messaging and accounts are not connected yet." else "نسخة أولية للواجهة — الحسابات والرسائل لم يتم ربطها بعد.",
            color = Muted, fontSize = 11.sp
        )
    }
}

@Composable
private fun SimpleScreen(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AutoAwesome, null, tint = Violet, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Muted)
    }
}

@Composable
private fun SettingsScreen(english: Boolean, onLanguageChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text(if (english) "Account" else "الحساب", color = Mint, fontWeight = FontWeight.Bold)
        SettingsRow(if (english) "Create your identity" else "إنشاء هويتك", if (english) "Nostr identity setup — next stage" else "إعداد هوية Nostr — المرحلة التالية")
        SettingsRow(if (english) "Privacy and security" else "الخصوصية والأمان", if (english) "Privacy controls and encryption" else "إعدادات الخصوصية والتشفير")
        SettingsRow(if (english) "Theme Studio" else "استوديو الثيمات", if (english) "Colors, wallpaper and chat bubbles" else "الألوان والخلفيات وفقاعات الدردشة")
        Spacer(Modifier.height(18.dp))
        Text(if (english) "Language" else "اللغة", color = Mint, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (english) "English" else "الإنجليزية", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = english, onCheckedChange = onLanguageChange)
        }
        Text(if (english) "العربية" else "Arabic", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        Text(if (english) "About CHARISMA" else "حول CHARISMA", color = Mint, fontWeight = FontWeight.Bold)
        SettingsRow("CHARISMA Ultimate Messenger", "Android Native • Version 1.0.0")
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
    HorizontalDivider(color = Color.White.copy(alpha = .06f))
}
